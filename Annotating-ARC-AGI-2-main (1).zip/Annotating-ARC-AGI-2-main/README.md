# Annotating-ARC-AGI-2
Just annotation code for arc-agi-2
